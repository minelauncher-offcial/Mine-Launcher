# MINE LAUNCHER — customized MojoLauncher source

This project is a customized fork of MojoLauncher (based on PojavLauncher).

## Changes in this customization
- App display name changed to **Mine Launcher**.
- Application ID changed to `com.exoblox.minelauncher` so it can coexist with the upstream MJ Launcher installation.
- Forest/grass-green palette applied to the launcher theme.
- Minecraft Ten font applied to the primary play button and home menu buttons.
- Added a Mine Launcher title to the main home screen.
- Recolored the existing nine-patch play-button assets toward grass green.
- Removed upstream release/upload signing keystores from this redistributed source.

## Build status
This source package has **not** been compiled into an APK. The original source ZIP has empty Git submodule directories (`glfw`, `mojoexec`, `sdl`, and `NoBlocklist`). The build also needs Gradle 8.14.5, Android SDK 36, NDK 29.0.14206865, and network access to fetch dependencies/components. In this execution environment, Gradle could not download from `services.gradle.org` because network DNS access is unavailable, and no Android SDK is installed.

The upstream README build command is `./gradlew :app_mojo:assembleDebug`; its CI workflow uses `:app_mojo:assembleFullDebug`. Complete submodules and the required SDK/NDK must be available before building.

## Licensing and attribution
The upstream MojoLauncher project is licensed under LGPL-3.0; retain the upstream `LICENSE` and applicable third-party notices. This customization does not claim ownership of the upstream launcher engine. The bundled Minecraft Ten font has its own OFL license in `app_mojo/src/main/assets/font/LICENSE_OFL.txt`.
